package com.cg.mra.service;

import com.cg.mra.beans.Account;

public class AccountServiceImpl implements AccountService{

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
