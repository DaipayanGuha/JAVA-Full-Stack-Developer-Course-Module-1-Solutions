package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao{
	
	Map<String,Account> accountEntry;

	public AccountDaoImpl() {
		accountEntry = new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",200));
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",453));
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",200));
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",200));
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",200));
		
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double rechargeAmount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
