package com.capgemini.salesmanagement.exceptions;

@SuppressWarnings("serial")
public class InvalidSaleIdException extends Exception{

	public InvalidSaleIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidSaleIdException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidSaleIdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidSaleIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidSaleIdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
