package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidQuantityException;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;

public class SaleService implements ISaleService{
	
	ISaleDAO serviceDAO = new SaleDAO();

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		return serviceDAO.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) throws InvalidProductCodeException {
		if(productId==1001 || productId==1002 || productId==1003 || productId==1004)
				return true;
		else
			throw new InvalidProductCodeException("Product Code is Invalid!");
	}

	@Override
	public boolean validateQuantity(int qty) throws InvalidQuantityException {
		if(qty>0 && qty<5)
				return true;
		else
			throw new InvalidQuantityException("Product Quantity is Invalid!");
	}

	@Override
	public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException {
		if(prodCat.equals("Electronics") || prodCat.equals("Toys"))
			return true;
	else
		throw new InvalidProductCategoryException("Product Category is Invalid!");
	}

	@Override
	public boolean validateProductName(String prodName) throws InvalidProductNameException, InvalidProductCategoryException {
		if(validateProductCat("Electronics")){
			if(prodName.equals("TV") || prodName.equals("Smart Phone") || prodName.equals("Video Game"))
				return true;
			else
				throw new InvalidProductNameException("Product Name is Invalid!");
		}
		else if(validateProductCat("Toys")){
			if(prodName.equals("Soft Toy") || prodName.equals("Telescope") || prodName.equals("Barbie Doll"))
				return true;
			else
				throw new InvalidProductNameException("Product Name is Invalid!");
		}
		else
			throw new InvalidProductNameException("Product Name is Invalid!");
	}

	@Override
	public boolean validateProductPrice(float price) throws InvalidProductPriceException {
		if(price>2000)
			return true;
	else
		throw new InvalidProductPriceException("Product Price is Invalid!");
	}

	@Override
	public Sale getSaleDetails(int saleId) throws InvalidSaleIdException {
		Sale sale = serviceDAO.findOne(saleId);
		if(sale==null)
			throw new InvalidSaleIdException("Invalid Sale ID!");
		return sale;
	}

}
