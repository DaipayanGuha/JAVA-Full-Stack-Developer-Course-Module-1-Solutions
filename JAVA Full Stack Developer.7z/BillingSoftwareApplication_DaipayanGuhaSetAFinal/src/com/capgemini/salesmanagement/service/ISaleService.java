package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidQuantityException;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;

public interface ISaleService {
	
	
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale);
	
	public boolean validateProductCode(int productId)throws InvalidProductCodeException;
	
	boolean validateQuantity(int qty)throws InvalidQuantityException;
	
	public boolean validateProductCat(String prodCat)throws InvalidProductCategoryException;
	
	public boolean validateProductName(String prodName)throws InvalidProductNameException, InvalidProductCategoryException;
	
	public boolean validateProductPrice(float price)throws InvalidProductPriceException;
	
	public Sale getSaleDetails(int saleId)throws InvalidSaleIdException;
	
}
