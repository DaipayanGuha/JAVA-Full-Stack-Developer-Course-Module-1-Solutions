package com.capgemini.salesmanagement.tests;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidQuantityException;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;




public class BillingTestCaseSetA {
	private static ISaleService services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new SaleService();
	}
	@Before
	public void setUpTestData() {
		
	}
	@Test(expected=InvalidProductCodeException.class)
	public void validateProductCodeForInvalidData() throws InvalidProductCodeException {
		services.validateProductCode(2000);
	}
	@Test
	public void validateProductCodeForValidData() throws InvalidProductCodeException {
		boolean expected=true;
		boolean actual=services.validateProductCode(1001);
		Assert.assertEquals(expected, actual);
	}
	@Test(expected=InvalidQuantityException.class)
	public void validateQuantityForInvalidData() throws InvalidQuantityException {
		services.validateQuantity(100);
	}
	@Test
	public void validateQuantityForValidData() throws InvalidQuantityException {
		boolean expected=true;
		boolean actual=services.validateQuantity(3);
		Assert.assertEquals(expected, actual);
	}
	@Test(expected=InvalidProductCategoryException.class)
	public void validateProductCategoryForInvalidData() throws InvalidProductCategoryException {
		services.validateProductCat("hgasfdhg");
	}
	@Test
	public void validateProductCategoryForValidData() throws InvalidProductCategoryException {
		boolean expected=true;
		boolean actual=services.validateProductCat("Toys");
		Assert.assertEquals(expected, actual);
	   }
		@Test(expected=InvalidProductNameException.class)
		public void validateProductNameForInvalidData() throws InvalidProductNameException, InvalidProductCategoryException {
			services.validateProductName("hsgddfsa");
		}
		@Test
		public void validateProductNameForValidData() throws InvalidProductNameException, InvalidProductCategoryException {
			boolean expected=true;
			boolean actual=services.validateProductName("TV");
			Assert.assertEquals(expected, actual);
	}
		@Test(expected=InvalidProductPriceException.class)
		public void validateProductPriceForInvalidData() throws InvalidProductPriceException {
			services.validateProductPrice(1000);
		}
		@Test
		public void validateProductPriceForValidData() throws InvalidProductPriceException {
			boolean expected=true;
			boolean actual=services.validateProductPrice(2500);
			Assert.assertEquals(expected, actual);
	}
//		@Test(expected=InvalidSaleIdException.class)
//		public void getSalesDetailsForInvalidData() throws InvalidProductPriceException {
//			services.validateProductPrice(1000);
//		}
//		@Test
//		public void getSalesDetailsForValidData() {
//			Sale expected;
//			Sale actual=services.getSaleDetails(1001);
//			Assert.assertEquals(expected, actual);
//	}
	
	@After
	public void tearDownTestData() {
	}
	@AfterClass
	public static void TearDownTestEnv() {
		services=null;
	}

}