package com.cg.departmentallocation.beans;

public class Student {
	private int studentId;
	private String studentName;
	private StudentGender studentGender;
	private String studentResidentialCity;
	private Department department;
	public Student() {
		super();
	}
	
	public Student(String studentName, StudentGender studentGender, String studentResidentialCity,
			Department department) {
		super();
		this.studentName = studentName;
		this.studentGender = studentGender;
		this.studentResidentialCity = studentResidentialCity;
		this.department = department;
	}

	public Student(int studentId, String studentName, StudentGender studentGender, String studentResidentialCity,
			Department department) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentGender = studentGender;
		this.studentResidentialCity = studentResidentialCity;
		this.department = department;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public StudentGender getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(StudentGender studentGender) {
		this.studentGender = studentGender;
	}
	public String getStudentResidentialCity() {
		return studentResidentialCity;
	}
	public void setStudentResidentialCity(String studentResidentialCity) {
		this.studentResidentialCity = studentResidentialCity;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((studentGender == null) ? 0 : studentGender.hashCode());
		result = prime * result + studentId;
		result = prime * result + ((studentName == null) ? 0 : studentName.hashCode());
		result = prime * result + ((studentResidentialCity == null) ? 0 : studentResidentialCity.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (studentGender != other.studentGender)
			return false;
		if (studentId != other.studentId)
			return false;
		if (studentName == null) {
			if (other.studentName != null)
				return false;
		} else if (!studentName.equals(other.studentName))
			return false;
		if (studentResidentialCity == null) {
			if (other.studentResidentialCity != null)
				return false;
		} else if (!studentResidentialCity.equals(other.studentResidentialCity))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "\nStudent [studentId=" + studentId + ", studentName=" + studentName + ", studentGender=" + studentGender
				+ ", studentResidentialCity=" + studentResidentialCity + ", department=" + department + "]";
	}
}
