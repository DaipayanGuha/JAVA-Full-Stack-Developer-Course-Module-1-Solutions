package com.cg.departmentallocation.beans;

public enum StudentGender {
	Male, Female, ThirdGender;
}
