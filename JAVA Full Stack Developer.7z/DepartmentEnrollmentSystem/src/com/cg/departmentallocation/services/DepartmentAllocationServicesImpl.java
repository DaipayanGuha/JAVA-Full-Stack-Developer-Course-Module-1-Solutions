package com.cg.departmentallocation.services;
import java.util.List;

import com.cg.departmentallocation.beans.Department;
import com.cg.departmentallocation.beans.Student;
import com.cg.departmentallocation.beans.StudentGender;
import com.cg.departmentallocation.daoservices.StudentDAOServicesImpl;
import com.cg.departmentallocation.exceptions.StudentNotFoundException;
public class DepartmentAllocationServicesImpl implements DepartmentAllocationServices {
private StudentDAOServicesImpl servicesDao = new StudentDAOServicesImpl();
	
	@Override
	public Student getStudentDetail(int studentId) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		Student student = servicesDao.findOne(studentId);
		if(student == null)
			throw new StudentNotFoundException("No such student is found with student ID : "+studentId);
		System.out.println("Student found with student ID :"+studentId);
		return student;
	}

	@Override
	public List<Student> getAllStudentDetails() {
		// TODO Auto-generated method stub
		List<Student> allStudents = servicesDao.findAll();
		return allStudents;
	}

	@Override
	public int acceptStudentDetails(String studentName, StudentGender studentGender, String studentResidentialCity,
			int deptId, String deptName, String deptHOD, int deptFloorNumber){
		// TODO Auto-generated method stub
		
		return servicesDao.save(
				new Student(studentName, studentGender, studentResidentialCity, 
						new Department(deptId, deptName, deptHOD, deptFloorNumber))).getStudentId();
	}
	
}
