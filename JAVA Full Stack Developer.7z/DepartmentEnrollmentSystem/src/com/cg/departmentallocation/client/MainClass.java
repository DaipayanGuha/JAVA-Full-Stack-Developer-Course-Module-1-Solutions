package com.cg.departmentallocation.client;
import com.cg.departmentallocation.beans.StudentGender;
import com.cg.departmentallocation.exceptions.StudentNotFoundException;
import com.cg.departmentallocation.services.DepartmentAllocationServices;
import com.cg.departmentallocation.services.DepartmentAllocationServicesImpl;
public class MainClass {
	public static void main(String[] args) {
DepartmentAllocationServices services = new DepartmentAllocationServicesImpl();
		

		int student1 = services.acceptStudentDetails("Daipayan Guha", StudentGender.Male, "Kolkata", 01, "C.S.E", "Swagata Pal", 1);
		int student2 = services.acceptStudentDetails("Tirtharaj Sur", StudentGender.Male, "Kolkata", 02, "C.S.E", "Swagata Pal", 2);
		int student3 = services.acceptStudentDetails("Pritam Chakraborty", StudentGender.Male, "Kolkata", 04, "C.S.E", "Swagata Pal", 3);
		
		try {
			System.out.println(services.getStudentDetail(student1));
		} catch (StudentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(services.getStudentDetail(student3));
		} catch (StudentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(services.getStudentDetail(120));
		} catch (StudentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Printing all student details :");
		System.out.println(services.getAllStudentDetails());
	}
}
