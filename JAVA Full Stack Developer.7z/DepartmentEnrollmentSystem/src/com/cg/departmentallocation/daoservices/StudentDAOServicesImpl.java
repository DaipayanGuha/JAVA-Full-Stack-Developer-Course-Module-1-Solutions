package com.cg.departmentallocation.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.departmentallocation.beans.Student;
import com.cg.departmentallocation.studentdb.util.StudentDBUtil;

public class StudentDAOServicesImpl implements StudentDAOServices{
	@Override
	public Student save(Student student) {
		// TODO Auto-generated method stub
		student.setStudentId(StudentDBUtil.getSTUDENT_ID());
		StudentDBUtil.studentDetails.put(student.getStudentId(), student);
		return student;
	}

	@Override
	public boolean update(Student student) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Student findOne(int studentId) {
		// TODO Auto-generated method stub
		
		return StudentDBUtil.studentDetails.get(studentId);
	}

	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return new ArrayList<Student>(StudentDBUtil.studentDetails.values());
	}

}
